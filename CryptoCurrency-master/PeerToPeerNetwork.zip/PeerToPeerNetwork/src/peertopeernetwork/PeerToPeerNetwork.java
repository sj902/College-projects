/*
 *This is aimed at creating P2P network for Assignemnt 1. 
 */
package peertopeernetwork;

//Import all necessary files 
import java.util.HashSet;
import java.net.Socket;
import java.net.ServerSocket;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author shubhamjain
 */
public class PeerToPeerNetwork {

    public static JSONObject parseJSON(String json) {
        JSONObject obj2;
        try {
            JSONParser parser = new JSONParser();
            JSONArray a = (JSONArray) parser.parse(json);
            obj2 = (JSONObject) a.get(0);
        } catch (ParseException ex) {
            obj2 = null;
            Logger.getLogger(PeerToPeerNetwork.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj2;
    }

    public static void main(String[] args) throws IOException {
        Thread DNSServer = new DNSServer();
        DNSServer.start();
        Node node1 = new Node();
        Node node2 = new Node();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            System.out.println(e);
        }

        Node node3 = new Node();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            System.out.println(e);
        }

        node1.sendToPort(node2.portNumber, "Hi");
        node3.sendToPort(node2.portNumber, "Hi 2");

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            System.out.println(e);
        }
        
        for(int i=0;i<100;++i){
        Node nodei = new Node();
        }
        
        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            System.out.println(e);
        }
        
        System.err.println("" + node3.cryptServers.size());
        System.err.println("" + node1.cryptServers.size());
        System.err.println("" + node2.cryptServers);
    }
}

/**
 * This class will mimic a node
 */
class Node extends Thread {

    public int portNumber;
    public int leftPort;
    public int rightPort;
    ServerSocket server;
    Socket socket = null;
    HashSet<String> UsedTransactionList = new HashSet<>();
    HashSet<String> UnusedTransactionList = new HashSet<>();
    Set<Integer> cryptServers = new HashSet<>();

    //Constructor to assign a portnumber to node and 
    //start listening on that port
    Node() {
        try {
            server = new ServerSocket(0);
            portNumber = server.getLocalPort();
            System.out.println("listening on port: " + server.getLocalPort());
            this.start();
            JSONObject message = new JSONObject();
            JSONArray list = new JSONArray();
            list.add("" + this.portNumber);
            message.put("type", "POST");
            message.put("wellknownServers", list);
            Socket s = new Socket("localhost", 60500);
            DataOutputStream dout = new DataOutputStream(s.getOutputStream());
            dout.writeUTF("[" + message.toJSONString() + "]");
            dout.flush();
            dout.close();
            s.close();
        } catch (IOException e) {
            System.out.println("peertopeernetwork.Node.<init>()" + e);
        }
    }

    //This function will be used to send Message to a particlar port
    public void sendToPort(int argPortNumber, String argMessage) {
        try {
            JSONObject message = new JSONObject();
            message.put("message", argMessage);
            try (Socket s = new Socket("localhost", argPortNumber); DataOutputStream dout = new DataOutputStream(s.getOutputStream())) {
                dout.writeUTF("[" + message.toJSONString() + "]");
                dout.flush();
            }
        } catch (IOException e) {
            System.out.println("peertopeernetwork.Node.sendToPort()::::" + e);
        }
    }

    public void sendToAll() {
        for(Object i : cryptServers)
        {
        try {
                System.out.println("peertopeernetwork.Node.sendToAll()" + this.portNumber + ":::" + i);
                JSONObject message = new JSONObject();
                message.put("type", "Hello");
                message.put("port", this.portNumber);
                Socket s = new Socket("localhost", Integer.parseInt(i+""));
                DataOutputStream dout = new DataOutputStream(s.getOutputStream());
                dout.writeUTF("[" + message.toJSONString() + "]");
                dout.flush();
                dout.close();
                s.close();
            } catch (IOException e) {
                System.out.println("peertopeernetwork.Node.sendToPort()::::" + e);
            }
        }
    }

    //This thread helps to keep listenong at the port
    @Override
    public void run() {
        while (true) {
            try {
                socket = server.accept();//establishes connection   
                DataInputStream dis = new DataInputStream(socket.getInputStream());
                String str = (String) dis.readUTF();
                JSONObject message = PeerToPeerNetwork.parseJSON(str);
                System.out.println("message= " + message);
                if (message.get("type") != null && message.get("type").toString().trim().equalsIgnoreCase("LIST")) {
                    this.cryptServers.addAll((ArrayList<Integer>) message.get("List"));
                    sendToAll();
                } else if (message.get("type") != null && message.get("type").toString().trim().equalsIgnoreCase("hello")) {
                    if(!this.cryptServers.contains(Integer.parseInt(message.get("port") + "")))    
                    this.cryptServers.add(Integer.parseInt(message.get("port") + ""));
                }
            } catch (IOException e) {
                System.out.println("peertopeernetwork.Node.listen()::"
                        + this.portNumber + ":::" + e.getMessage());
            }
        }
    }
}
